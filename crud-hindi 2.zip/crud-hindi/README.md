## lab-mongodb-nodejs
Instructions: To install dependencies - npm install To run the code in live reload mode, use command - npm run dev To run the app - npm start

Note: If you are running an application on a port XXXX, copy the url from the bar and attach the url with port https://your-url.pwskills.app:XXXX to see the output.